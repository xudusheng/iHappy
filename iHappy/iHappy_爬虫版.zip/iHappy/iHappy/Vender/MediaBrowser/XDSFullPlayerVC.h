//
//  XDSFullPlayerVC.h
//  iHappy
//
//  Created by Hmily on 2018/8/25.
//  Copyright © 2018年 dusheng.xu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XDSPlayerView.h"
@interface XDSFullPlayerVC : UIViewController

@property (strong, nonatomic) XDSPlayerView *playerView;

@end
