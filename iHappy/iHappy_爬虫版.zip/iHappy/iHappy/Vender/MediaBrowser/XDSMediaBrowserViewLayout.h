//
//  XDSMediaBrowserViewLayout.h
//  XDSPhotoBrowser
//
//  Created by Hmily on 2018/8/21.
//  Copyright © 2018年 dusheng.xu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDSMediaBrowserViewLayout : UICollectionViewFlowLayout

@property (nonatomic, assign) CGFloat gapBetweenPages;

@end
