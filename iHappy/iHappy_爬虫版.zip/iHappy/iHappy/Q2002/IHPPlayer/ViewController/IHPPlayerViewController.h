//
//  IHPPlayerViewController.h
//  iHappy
//
//  Created by xudosom on 2017/5/5.
//  Copyright © 2017年 上海优蜜科技有限公司. All rights reserved.
//

#import "XDSBaseViewController.h"
#import "IHYMovieModel.h"
@interface IHPPlayerViewController : XDSBaseViewController

@property (strong, nonatomic)IHYMovieModel * movieModel;

@end

