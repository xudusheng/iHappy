//
//  IHPConfigModel.m
//  iHappy
//
//  Created by dusheng.xu on 2017/4/25.
//  Copyright © 2017年 上海优蜜科技有限公司. All rights reserved.
//

#import "IHPConfigModel.h"

@implementation IHPConfigModel

@end
