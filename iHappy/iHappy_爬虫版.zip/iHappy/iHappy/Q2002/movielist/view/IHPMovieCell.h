//
//  IHPMovieCell.h
//  iHappy
//
//  Created by xudosom on 2016/11/19.
//  Copyright © 2016年 上海优蜜科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IHYMovieModel.h"
@interface IHPMovieCell : UICollectionViewCell

    - (void)cellWithMovieModel:(IHYMovieModel *)movieModel;
    
@end
