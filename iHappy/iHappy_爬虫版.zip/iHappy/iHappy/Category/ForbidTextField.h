//
//  ForbidTextField.h
//  Thumb
//
//  Created by ios on 14-12-8.
//  Copyright (c) 2014年 peter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForbidTextField : UITextField

@end
