//
//  XDSWebViewController.h
//  Laomoney
//
//  Created by zhengda on 15/10/20.
//  Copyright © 2015年 zhengda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDSWebViewController : XDSBaseViewController

@property (strong, nonatomic)NSString * requestURL;

@end
