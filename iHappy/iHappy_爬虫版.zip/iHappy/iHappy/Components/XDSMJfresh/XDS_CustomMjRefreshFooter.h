//
//  XDS_CustomMjRefreshFooter.m
//  iHappy
//
//  Created by Hmily on 2018/8/9.
//  Copyright © 2018年 dusheng.xu. All rights reserved.
//


#import <MJRefresh/MJRefresh.h>

@interface XDS_CustomMjRefreshFooter : MJRefreshAutoFooter

@end
