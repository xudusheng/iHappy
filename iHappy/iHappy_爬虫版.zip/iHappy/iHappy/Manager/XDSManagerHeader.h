
//
//  XDSManagerHeader.h
//  iHappy
//
//  Created by Hmily on 2018/8/24.
//  Copyright © 2018年 dusheng.xu. All rights reserved.
//

#ifndef XDSManagerHeader_h
#define XDSManagerHeader_h

#import "XDSAdManager.h"
#import "XDSLocalizableManager.h"

#endif /* XDSManagerHeader_h */
