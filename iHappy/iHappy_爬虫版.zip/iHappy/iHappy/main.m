//
//  main.m
//  iHappy
//
//  Created by xudosom on 2016/11/19.
//  Copyright © 2016年 上海优蜜科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

//
//#pragma mark - UI相关
//- (void)createOCMainTabBarControllerUI{
//
//}
//
//#pragma mark - 网络请求
//
//#pragma mark - 代理方法
//
//#pragma mark - 点击事件处理
//
//#pragma mark - 其他私有方法
//
//#pragma mark - 内存管理相关
//- (void)ocMainTabBarControllerDataInit{
//
//}



//sudo apachectl start
//
