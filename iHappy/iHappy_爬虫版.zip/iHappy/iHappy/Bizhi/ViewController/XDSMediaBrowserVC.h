//
//  XDSMediaBrowserVC.h
//  iHappy
//
//  Created by Hmily on 2018/8/25.
//  Copyright © 2018年 dusheng.xu. All rights reserved.
//

#import "XDSBaseViewController.h"
#import "XDSMediaModel.h"
@interface XDSMediaBrowserVC : XDSBaseViewController


@property (nonatomic,strong) NSArray<XDSMediaModel *> *mediaModelArray;

@end

