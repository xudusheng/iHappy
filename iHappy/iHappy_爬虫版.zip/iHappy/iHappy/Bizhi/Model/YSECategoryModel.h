//
//  YSECategoryModel.h
//  iHappy
//
//  Created by dusheng.xu on 2017/5/14.
//  Copyright © 2017年 上海优蜜科技有限公司. All rights reserved.
//

#import "YSEClassifyModel.h"

@interface YSECategoryModel : YSEClassifyModel

@end
