//
//  ZALoadFailView.h
//  Thumb
//
//  Created by zhengda on 15/4/17.
//  Copyright (c) 2015年 peter. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ZDLoadFailView : UIView
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title topGap:(CGFloat)topGap;
@end
