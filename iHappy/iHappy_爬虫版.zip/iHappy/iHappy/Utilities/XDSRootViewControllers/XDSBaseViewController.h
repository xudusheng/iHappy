//
//  XDSRootViewController.h
//  Jurongbao
//
//  Created by wangrongchao on 15/10/17.
//  Copyright © 2015年 truly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDSBaseViewController : XDSRootRequestViewController

- (void)popBack:(UIBarButtonItem *)barButtonItem;

@end
